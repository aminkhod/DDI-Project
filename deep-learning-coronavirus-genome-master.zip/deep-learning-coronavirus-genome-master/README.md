# Identification of SARS-CoV-2 from Genome Sequences using Deep Learning
Repository with data and code for the paper "Identification of SARS-CoV-2 from Genome Sequences using Deep Learning", currently uploaded to BiorXiv.

## Corona V4.2
Contains data and scripts for the first batch of experiments, multi-label classification.

## Corona V5.2
Contains data and scripts for the second batch of experiment, binary classification.
