This is a modified version of the code given by Zhang et al.
https://github.com/zw9977129/drug-drug-interaction
A comparision with AMF and XGBoost ensemble was added.
The data needs to be placed as instructed in the original repository.
Additionally, two folder should be created here: "pickles" and "result".