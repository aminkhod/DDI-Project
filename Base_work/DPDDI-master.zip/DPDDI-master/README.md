This is a TensorFlow implementation of the DPDDI model as described in our paper:

DPDDI: a Deep Predictor for Drug-Drug Interactions

The code of GAE is used code from paper: T. N. Kipf, M. Welling, Variational Graph Auto-Encoders, NIPS Workshop on Bayesian Deep Learning (2016).

Requirements

TensorFlow (1.0 or later)
python 2.7
networkx
scikit-learn
scipy

